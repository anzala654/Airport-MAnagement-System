﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using PdfiumViewer;
using Xceed.Words.NET;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas.Parser;
using PdfDocument = iText.Kernel.Pdf.PdfDocument;

namespace Airport_MS
{
   
        public partial class home : Window
        {
            public home()
            {
                InitializeComponent();
            }

            private void FlightManagement_Click(object sender, RoutedEventArgs e)
            {
                flight_management flightManagementScreen = new flight_management();
                flightManagementScreen.Show();
                this.Close(); // Close the home screen if needed
            }

        private void UploadFile_Click(object sender, RoutedEventArgs e)
        {
            // Configure the Open File Dialog
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Filter = "PDF files (*.pdf)|*.pdf|Text files (*.txt)|*.txt|Word documents (*.doc;*.docx)|*.doc;*.docx";

            // Show the dialog and get the result
            if (openFileDialog.ShowDialog() == true)
            {
                try
                {
                    // Get the file path
                    string filePath = openFileDialog.FileName;

                    // Read the file content based on file type
                    string fileContent = string.Empty;

                    if (filePath.EndsWith(".pdf"))
                    {
                        fileContent = ReadPdfFile(filePath);
                    }
                    else if (filePath.EndsWith(".txt"))
                    {
                        fileContent = File.ReadAllText(filePath);
                    }
                    else if (filePath.EndsWith(".doc") || filePath.EndsWith(".docx"))
                    {
                        fileContent = ReadWordFile(filePath);
                    }

                    // Display the file content in the TextBox
                    FileContentTextBox.Text = fileContent;
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"An error occurred while uploading the file: {ex.Message}", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                }
            }
        }
        private string ReadPdfFile(string filePath)
        {
            StringBuilder text = new StringBuilder();

            using (PdfReader reader = new PdfReader(filePath))
            {
                using (PdfDocument pdfDoc = new PdfDocument(reader))
                {
                    for (int page = 1; page <= pdfDoc.GetNumberOfPages(); page++)
                    {
                        text.Append(PdfTextExtractor.GetTextFromPage(pdfDoc.GetPage(page)));
                    }
                }
            }

            return text.ToString();
        }

        private string ReadWordFile(string filePath)
        {
            using (DocX document = DocX.Load(filePath))
            {
                return document.Text;
            }
        }


        private void Tickets_Click(object sender, RoutedEventArgs e)
            {
                Tickets ticketsScreen = new Tickets();
                ticketsScreen.Show();
                this.Close(); // Close the home screen if needed
            }

            private void Passengers_Click(object sender, RoutedEventArgs e)
            {
                Passengers passengersScreen = new Passengers();
                passengersScreen.Show();
                this.Close(); // Close the home screen if needed
            }

            private void Baggage_Click(object sender, RoutedEventArgs e)
            {
                Bag baggageScreen = new Bag();
                baggageScreen.Show();
                this.Close(); // Close the home screen if needed
            }
        private void Logout_Click(object sender, RoutedEventArgs e)
        {
            Login loginScreen = new Login(); // Assuming LoginScreen is the login window
            loginScreen.Show();
            this.Close(); // Close the home screen
        }
    }
    }
