﻿using System.Text;
using System.Windows;
using System;
using System.Data.SqlClient;


namespace Airport_MS
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Login ln;
     
        public MainWindow()
        {
            InitializeComponent();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            
            Login ln = new Login();
            ln.Show();
            this.Close();

        }
    }
}