﻿using System.Security.Cryptography;
using System.Text;

namespace Airport_MS
{
    public class SecureData
    {
        public static string HashString(string passwordstring)
        {
            StringBuilder sb = new StringBuilder();
            foreach (byte b in GetHash(passwordstring))
            {
                sb.Append(b.ToString("X2"));
            }
            return sb.ToString();
        }

        public static byte[] GetHash(string passwordString)
        {
            using (HashAlgorithm sha = SHA256.Create())
            {
                return sha.ComputeHash(Encoding.UTF8.GetBytes(passwordString));
            }
        }
    }
}
