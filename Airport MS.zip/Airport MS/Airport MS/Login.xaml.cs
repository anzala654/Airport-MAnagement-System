﻿using System;
using System.Data.SqlClient;
using System.Windows;

namespace Airport_MS
{
    /// <summary>
    /// Interaction logic for login.xaml
    /// </summary>
    public partial class Login : Window
    {
        private SqlConnection sqlcon = new SqlConnection("Data Source=DESKTOP-SC4J9Q2\\SQLEXPRESS;Initial Catalog=airport_management;Integrated Security=True");

        public sign_up sign;
        public flight_management flights;
        public Login()
        {
            InitializeComponent();
        }

        private void Clear_all(object sender, RoutedEventArgs e)
        {
            // Clear All button click event logic
            txtEmail.Clear();
            txtPassword.Clear();
        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            sign = new sign_up();
            this.Close();
            sign.Show();
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            string email = txtEmail.Text;
            string password = txtPassword.Password;
            string hashedPassword = SecureData.HashString(password);

            // Connecting to the database
            using (SqlConnection connection = new SqlConnection("Data Source=DESKTOP-SC4J9Q2\\SQLEXPRESS;Initial Catalog=airport_management;Integrated Security=True"))
            {
                try
                {
                    connection.Open();

                    // Implement your database query or authentication logic here
                    // Example: Checking user credentials
                    string query = "SELECT * FROM Signup WHERE Email = @Email AND Password = @Password";
                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@email", email);
                        command.Parameters.AddWithValue("@password", hashedPassword);

                        // Execute the query and check the result
                        SqlDataReader reader = command.ExecuteReader();
                        if (reader.HasRows)
                        {
                            MessageBox.Show("Login successful!");
                            // Perform actions after successful login
                            home homeScreen = new home();
                            homeScreen.Show();
                            this.Close(); // Close the current window if needed
                        }
                        else
                        {
                            MessageBox.Show("Invalid email or password. Please try again.");
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error: {ex.Message}");
                }
            }
        }
    }
}
