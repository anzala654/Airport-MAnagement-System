﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Runtime.Intrinsics.Arm;
using System.Windows;

namespace Airport_MS
{
    /// <summary>
    /// Interaction logic for flight_management.xaml
    /// </summary>
    public partial class flight_management : Window
    {
        private string connectionString = "Data Source=DESKTOP-SC4J9Q2\\SQLEXPRESS;Initial Catalog=airport_management;Integrated Security=True";

        public flight_management()
        {
            InitializeComponent();
            // Load data into the DataGrid on window load
            LoadData();
        }
        private void Home_Click(object sender, RoutedEventArgs e)
        {
            // Assuming HomeScreen is another window
            home homeScreen = new home();
            homeScreen.Show();
            this.Close(); // Close the current window if needed
        }
        private void LoadData()
        {
            try
            {
                using (SqlConnection sqlcon = new SqlConnection(connectionString))
                {
                    sqlcon.Open();
                    SqlDataAdapter sqlDa = new SqlDataAdapter("SELECT * FROM Flights", sqlcon);
                    DataTable dt = new DataTable();
                    sqlDa.Fill(dt);
                    FlightsDataGrid.ItemsSource = dt.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}");
            }
        }

        private void Update1(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection sqlcon = new SqlConnection(connectionString))
                {
                    sqlcon.Open();
                    SqlCommand cmd = new SqlCommand("UPDATE Flights SET flight_number = @flight_number, departure_time = @departure_time, arrival_time = @arrival_time", sqlcon);
                    cmd.Parameters.AddWithValue("@flight_number", fnum.Text);
                    cmd.Parameters.AddWithValue("@departure_time", dep_Copy.SelectedDate ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@arrival_time", aa_Copy.SelectedDate ?? (object)DBNull.Value);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Flight updated successfully.");
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("Flight not found.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating flight: {ex.Message}");
            }
        }

        private void Search1(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection sqlcon = new SqlConnection(connectionString))
                {
                    sqlcon.Open();
                    string query = "SELECT * FROM Flights WHERE flight_number = @flight_number";
                    SqlCommand cmd = new SqlCommand(query, sqlcon);
                    cmd.Parameters.AddWithValue("@flight_number", Searchflightid.Text);

                    SqlDataAdapter sqlDa = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    sqlDa.Fill(dt);
                    FlightsDataGrid.ItemsSource = dt.DefaultView;

                    if (dt.Rows.Count == 0)
                    {
                        MessageBox.Show("No flight found with the given flight number.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching for flight: {ex.Message}");
            }
        }

        private void add1(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection sqlcon = new SqlConnection(connectionString))
                {
                    sqlcon.Open();
                    string query = "INSERT INTO Flights (flight_number, departure_time, arrival_time, origin_id, destination_id, airline_id) VALUES (@flight_number, @departure_time, @arrival_time, @origin_id, @destination_id, @airline_id)";
                    SqlCommand cmd = new SqlCommand(query, sqlcon);

                    cmd.Parameters.AddWithValue("@flight_number", fnumm.Text);
                    cmd.Parameters.AddWithValue("@departure_time", adddep.SelectedDate ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@arrival_time", addaa.SelectedDate ?? (object)DBNull.Value);
                    cmd.Parameters.AddWithValue("@origin_id", originid.Text);
                    cmd.Parameters.AddWithValue("@destination_id", destinationid.Text);
                    cmd.Parameters.AddWithValue("@airline_id", airlineid.Text);

                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Flight added successfully.");
                        LoadData();
                    }
                    else
                    {
                        MessageBox.Show("Failed to add flight.");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding flight: {ex.Message}");
            }
        }




        // Ensure other methods such as Search1 and Add1 are implemented similarly
    }
}
