﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace Airport_MS
{
    /// <summary>
    /// Interaction logic for Tickets.xaml
    /// </summary>
    public partial class Tickets : Window
    {
        private string sqlcon = "Data Source=DESKTOP-SC4J9Q2\\SQLEXPRESS;Initial Catalog=airport_management;Integrated Security=True";

        public Tickets()
        {
            InitializeComponent();
            // Load data into the DataGrid on window load
            LoadData();
        }

        private void LoadData()
        {
            // Implementation for loading data into FlightsDataGrid
        }

        private void make_ticket(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sqlcon))
                {
                    con.Open();
                    string query = "INSERT INTO Tickets (flight_id, passenger_id, seat_number, price) VALUES (@flight_id, @passenger_id, @seat_number, @price)";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@flight_id", int.Parse(fid.Text));
                        cmd.Parameters.AddWithValue("@passenger_id", int.Parse(pid.Text));
                        cmd.Parameters.AddWithValue("@seat_number", snn.Text);
                        cmd.Parameters.AddWithValue("@price", decimal.Parse(pp.Text));

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Ticket added successfully.");
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to add ticket.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding ticket: {ex.Message}");
            }
        }
        private void Home(object sender, RoutedEventArgs e)
        {
            // Assuming HomeScreen is another window
            home homeScreen = new home();
            homeScreen.Show();
            this.Close(); // Close the current window if needed
        }
        private void Search2(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sqlcon))
                {
                    con.Open();
                    string query = "SELECT * FROM Tickets WHERE ticket_id = @ticket_id";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@ticket_id", int.Parse(SearchTicketID.Text));
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        FlightsDataGrid.ItemsSource = dt.DefaultView;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching ticket: {ex.Message}");
            }
        }

        private void Update2(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sqlcon))
                {
                    con.Open();
                    string query = "UPDATE Tickets SET seat_number = @seat_number, price = @price WHERE ticket_id = @ticket_id";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@ticket_id", int.Parse(tid.Text));
                        cmd.Parameters.AddWithValue("@seat_number", sn.Text);
                        cmd.Parameters.AddWithValue("@price", decimal.Parse(p.Text));

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Ticket updated successfully.");
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to update ticket.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating ticket: {ex.Message}");
            }
        }
    }
}
