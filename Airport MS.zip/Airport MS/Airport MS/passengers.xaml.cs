﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;

namespace Airport_MS
{
    /// <summary>
    /// Interaction logic for Passengers.xaml
    /// </summary>
    public partial class Passengers : Window
    {
        private string sqlcon = "Data Source=DESKTOP-SC4J9Q2\\SQLEXPRESS;Initial Catalog=airport_management;Integrated Security=True";

        public Passengers()
        {
            InitializeComponent();
            // Load data into the DataGrid on window load
            LoadData();
        }

        private void LoadData()
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sqlcon))
                {
                    con.Open();
                    string query = "SELECT * FROM Passengers";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        PassengersDataGrid.ItemsSource = dt.DefaultView;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error loading data: {ex.Message}");
            }
        }

        private void Search2(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sqlcon))
                {
                    con.Open();
                    string query = "SELECT * FROM Passengers WHERE passenger_id = @passenger_id";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@passenger_id", int.Parse(passengersID.Text));
                        SqlDataAdapter da = new SqlDataAdapter(cmd);
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        PassengersDataGrid.ItemsSource = dt.DefaultView;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error searching passenger: {ex.Message}");
            }
        }

        private void Update3(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sqlcon))
                {
                    con.Open();
                    string query = "UPDATE Passengers SET passport_number = @passport_number, nationality = @nationality, first_name = @first_name, last_name = @last_name WHERE passenger_id = @passenger_id";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@passenger_id", int.Parse(tid.Text));
                        cmd.Parameters.AddWithValue("@passport_number", pnn.Text);
                        cmd.Parameters.AddWithValue("@nationality", nat.Text);
                        cmd.Parameters.AddWithValue("@first_name", fnn.Text);
                        cmd.Parameters.AddWithValue("@last_name", lnn.Text);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Passenger updated successfully.");
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to update passenger.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error updating passenger: {ex.Message}");
            }
        }

        private void done(object sender, RoutedEventArgs e)
        {
            try
            {
                using (SqlConnection con = new SqlConnection(sqlcon))
                {
                    con.Open();
                    string query = "INSERT INTO Passengers (first_name, last_name, passport_number, nationality) VALUES (@first_name, @last_name, @passport_number, @nationality)";
                    using (SqlCommand cmd = new SqlCommand(query, con))
                    {
                        cmd.Parameters.AddWithValue("@first_name", fn.Text);
                        cmd.Parameters.AddWithValue("@last_name", ln.Text);
                        cmd.Parameters.AddWithValue("@passport_number", pn.Text);
                        cmd.Parameters.AddWithValue("@nationality", n.Text);

                        int rowsAffected = cmd.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Passenger added successfully.");
                            LoadData();
                        }
                        else
                        {
                            MessageBox.Show("Failed to add passenger.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Error adding passenger: {ex.Message}");
            }
        }

        private void Home_Click(object sender, RoutedEventArgs e)
        {
            home homeScreen = new home();
            homeScreen.Show();
            this.Close();
        }
    }
}
