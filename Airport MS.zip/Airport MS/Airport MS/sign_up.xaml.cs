﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Windows;
using System.Xml.Linq;

namespace Airport_MS
{
    /// <summary>
    /// Interaction logic for sign_up.xaml
    /// </summary>
    public partial class sign_up : Window
    {
        public Login login;
        private SqlConnection sqlcon = new SqlConnection("Data Source=DESKTOP-SC4J9Q2\\SQLEXPRESS;Initial Catalog=airport_management;Integrated Security=True");


        public sign_up()
        {
            InitializeComponent();
        }
        bool validation()
        {
            if (string.IsNullOrWhiteSpace(txtName.Text) || string.IsNullOrWhiteSpace(txtContact.Text) ||
                string.IsNullOrWhiteSpace(txtEmail.Text) || string.IsNullOrWhiteSpace(SecureData.HashString(txtPassword.Password)))
            {
                MessageBox.Show("Fill the form to submit ", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!box.IsChecked == true)
            {
                // Display a popup with a message
                MessageBox.Show("Accept the Terms and Conditions to submit the form.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Error);

                // Exit the method if validation fails
                return false;
            }

            if (!Isnamevalid(txtName.Text))
            {
                MessageBox.Show("Name should not contain numeric or special characters", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            if (!Isphonevalid(txtContact.Text))
            {
                MessageBox.Show("Phone should only contain numeric characters.", "Validation Error", MessageBoxButton.OK, MessageBoxImage.Error);
                return false;
            }

            // Exit the method if validation fails
            return true;
        }

        bool Isnamevalid(string name)
        {
            return name.All(char.IsLetter) || name.All(char.IsDigit);
        }

        bool Isphonevalid(string phone)
        {
            return phone.All(char.IsDigit);
        }

        private void Submit1(object sender, RoutedEventArgs e)
        {
            try
            {
                if (sqlcon.State == ConnectionState.Closed)
                    sqlcon.Open();

                if (validation())
                {
                    string query = "INSERT INTO Signup (Name, Phone, Email, Password) VALUES (@Name, @Phone, @Email, @Password)";
                    SqlCommand sqlcmd = new SqlCommand(query, sqlcon);
                    sqlcmd.CommandType = CommandType.Text;


                    sqlcmd.Parameters.AddWithValue("@Name", txtName.Text);
                    sqlcmd.Parameters.AddWithValue("@Phone", txtContact.Text);
                    sqlcmd.Parameters.AddWithValue("@Email", txtEmail.Text);
                    sqlcmd.Parameters.AddWithValue("@Password", SecureData.HashString(txtPassword.Password));


                    int rowsAffected = sqlcmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Signup successful! Form submitted to the database.", "Success", MessageBoxButton.OK, MessageBoxImage.Information);


                        login = new Login();
                        this.Close();
                        login.Show();


                    }
                    else
                    {
                        MessageBox.Show("Signup failed. Please try again.", "Error", MessageBoxButton.OK, MessageBoxImage.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message, "Error", MessageBoxButton.OK, MessageBoxImage.Error);
            }
            finally
            {
                sqlcon.Close();
            }

        }
        private void Hyperlink_Click(object sender, RoutedEventArgs e)
        {
            // Handle the hyperlink click event here
            MessageBox.Show("1. Adhere to all airport regulations.\r\n\r\n" +
                            "2. Follow security guidelines at all times.\r\n\r\n" +
                            "3. Ensure all information provided is accurate.\r\n\r\n" +
                            "4. Respect the privacy of other passengers.\r\n\r\n" +
                            "5. Report any suspicious activities to airport authorities immediately.\r\n\r\n" +
                            "6. Ensure timely payment of all applicable fees.\r\n\r\n" +
                            "7. Support the airport staff and cooperate during security checks.\r\n\r\n" +
                            "8. Stay informed about any changes in flight schedules.",
                            "Terms and Conditions");
            // You can navigate to a URL or perform other actions as needed
        }


       

        private void CheckBox_Check(object sender, RoutedEventArgs e)
        {
            MessageBox.Show("Terms and Conditions accepted");
        }

        private void Login2(object sender, RoutedEventArgs e)
        {


            login = new Login();
            this.Close();
            login.Show();
        }
    }
}
